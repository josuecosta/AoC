﻿using System;

namespace Aoc21
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            var result = new Solutions();
            Console.WriteLine(result.Solution);
        }
    }
}
